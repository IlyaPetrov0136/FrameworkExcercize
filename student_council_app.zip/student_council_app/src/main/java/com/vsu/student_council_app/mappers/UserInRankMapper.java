package com.vsu.student_council_app.mappers;

import com.vsu.student_council_app.Entity.UserInRank;
import com.vsu.student_council_app.dto.UserInRankDTO;
import com.vsu.student_council_app.request.create.CreateUserInRankRequest;
import com.vsu.student_council_app.request.update.UpdateUserInRankRequest;
import org.springframework.stereotype.Component;

@Component
public class UserInRankMapper {
    public UserInRankDTO userInRankToUserInRankDTO(UserInRank userInRank) {
        UserInRankDTO userInRankDTO = new UserInRankDTO();
        userInRankDTO.setId(userInRank.getId());
        userInRankDTO.setRankId(userInRank.getRankId());
        userInRankDTO.setStartDate(userInRank.getStartDate());
        userInRankDTO.setEndDate(userInRank.getEndDate());
        userInRankDTO.setUserId(userInRank.getUserId());
        return userInRankDTO;
    }

    public UserInRank createUserInRankRequestToUserInRank(CreateUserInRankRequest createUserInRankRequest) {
        UserInRank userInRank = new UserInRank();
        userInRank.setUserId(createUserInRankRequest.getUserId());
        userInRank.setRankId(createUserInRankRequest.getRankId());
        userInRank.setStartDate(createUserInRankRequest.getStartDate());
        userInRank.setEndDate(createUserInRankRequest.getEndDate());
        return userInRank;
    }

    public UserInRank updateUserInRankRequestToUserInRank(UpdateUserInRankRequest userInRank) {
        UserInRank userInRankUpdate = new UserInRank();
        userInRankUpdate.setId(userInRank.getId());
        userInRankUpdate.setRankId(userInRank.getRankId());
        userInRankUpdate.setStartDate(userInRank.getStartDate());
        userInRankUpdate.setEndDate(userInRank.getEndDate());
        userInRankUpdate.setUserId(userInRank.getUserId());
        return userInRankUpdate;
    }
}
