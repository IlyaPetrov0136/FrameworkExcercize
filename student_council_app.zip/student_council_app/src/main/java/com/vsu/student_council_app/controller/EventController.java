package com.vsu.student_council_app.controller;

import com.vsu.student_council_app.dto.EventDTO;
import com.vsu.student_council_app.dto.EventStatusDTO;
import com.vsu.student_council_app.request.create.CreateEventRequest;
import com.vsu.student_council_app.request.create.CreateEventStatusRequest;
import com.vsu.student_council_app.request.update.UpdateEventRequest;
import com.vsu.student_council_app.request.update.UpdateEventStatusRequest;
import com.vsu.student_council_app.service.EventService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/event")
public class EventController {
    private final EventService eventService;

    public EventController(EventService eventService) {
        this.eventService = eventService;
    }

    @GetMapping("/{id}")
    public EventDTO getEvent(@PathVariable Long id) {
        return eventService.getEventById(id);
    }

    @PostMapping("")
    public EventDTO createEvent(@RequestBody CreateEventRequest request) {
        return eventService.createEvent(request);
    }

    @PutMapping("")
    public EventDTO updateEvent(@RequestBody UpdateEventRequest request) {
        return eventService.updateEvent(request);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteEvent(@PathVariable Long id) {
        eventService.deleteEvent(id);
    }

    @GetMapping("/status/{id}")
    public EventStatusDTO getEventStatus(@PathVariable Long id) {
        return eventService.getEventStatusById(id);
    }

    @PostMapping("/status")
    public EventStatusDTO createEventStatus(@RequestBody CreateEventStatusRequest request) {
        return eventService.createEventStatus(request);
    }

    @PutMapping("/status")
    public EventStatusDTO updateEventStatus(@RequestBody UpdateEventStatusRequest request) {
        return eventService.updateEventStatus(request);
    }

    @DeleteMapping("/status/delete/{id}")
    public void deleteEventStatus(@PathVariable Long id) {
        eventService.deleteEventStatus(id);
    }
}
