package com.vsu.student_council_app.request.create;

import java.sql.Date;

public class CreateEventRequest {
    private long departmentId;
    private long eventStatusId;
    private String title;
    private String description;
    private Date startDate;
    private Date endDate;
    private Short auditory;

    public long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(long departmentId) {
        this.departmentId = departmentId;
    }

    public long getEventStatusId() {
        return eventStatusId;
    }

    public void setEventStatusId(long eventStatusId) {
        this.eventStatusId = eventStatusId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Short getAuditory() {
        return auditory;
    }

    public void setAuditory(Short auditory) {
        this.auditory = auditory;
    }
}
