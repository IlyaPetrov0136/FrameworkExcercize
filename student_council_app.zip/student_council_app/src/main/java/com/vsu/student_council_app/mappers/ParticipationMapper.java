package com.vsu.student_council_app.mappers;


import com.vsu.student_council_app.Entity.Participation;
import com.vsu.student_council_app.dto.ParticipationDTO;
import org.springframework.stereotype.Component;

@Component
public class ParticipationMapper {
    public ParticipationDTO toParticipationDTO(Participation participation) {
        return new ParticipationDTO(participation.getId(),
                participation.getEventId(),
                participation.getUserId(),
                participation.getStatus(),
                participation.getReason(),
                participation.getRegisteredAt());
    }

}
