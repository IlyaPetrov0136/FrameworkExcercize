package com.vsu.student_council_app.mappers;

import com.vsu.student_council_app.Entity.TaskComment;
import com.vsu.student_council_app.dto.TaskCommentDTO;
import com.vsu.student_council_app.request.create.CreateTaskCommentRequest;
import com.vsu.student_council_app.request.update.UpdateTaskCommentRequest;
import org.springframework.stereotype.Component;

@Component
public class TaskCommentMapper {
    public TaskCommentDTO taskCommentToTaskCommentDTO(TaskComment taskComment) {
        TaskCommentDTO taskCommentDTO = new TaskCommentDTO();
        taskCommentDTO.setId(taskComment.getId());
        taskCommentDTO.setTaskId(taskComment.getTaskId());
        taskCommentDTO.setUserId(taskComment.getUserId());
        taskCommentDTO.setContent(taskComment.getContent());
        taskCommentDTO.setCreatedAt(taskComment.getCreatedAt());
        return taskCommentDTO;
    }

    public TaskComment createTaskCommentRequestToTaskComment(CreateTaskCommentRequest createTaskCommentRequest) {
        TaskComment taskComment = new TaskComment();
        taskComment.setUserId(createTaskCommentRequest.getUserId());
        taskComment.setTaskId(createTaskCommentRequest.getTaskId());
        taskComment.setContent(createTaskCommentRequest.getContent());
        taskComment.setCreatedAt(createTaskCommentRequest.getCreatedAt());
        return taskComment;
    }
    public TaskComment updateTaskCommentRequestToTaskComment(UpdateTaskCommentRequest updateTaskCommentRequest) {
        TaskComment taskComment = new TaskComment();
        taskComment.setId(updateTaskCommentRequest.getId());
        taskComment.setTaskId(updateTaskCommentRequest.getTaskId());
        taskComment.setUserId(updateTaskCommentRequest.getUserId());
        taskComment.setContent(updateTaskCommentRequest.getContent());
        taskComment.setCreatedAt(updateTaskCommentRequest.getCreatedAt());
        return taskComment;
    }
}
