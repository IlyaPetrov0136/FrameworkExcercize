package com.vsu.student_council_app.Entity;

import jakarta.persistence.*;
import org.hibernate.validator.constraints.Length;

import java.sql.Date;

@Entity
@Table(name = "User")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Long id;

    @Column(name = "login")
    @Length(min = 6, message = "Login must be at least 6 symbols")
    private String login;

    @Column(name = "password")
    private String password;

    @Column(name = "salt")
    private String salt;

    @Column(name = "direction_id")
    private int directionId;

    @Column(name = "department_id")
    private long departmentId;

    @Column(name = "user_username")
    private String userName;

    @Column(name = "user_name")
    private String name;

    @Column(name = "user_lastname")
    private String lastName;

    @Column(name = "user_patronymic")
    private String patronymic;

    @Column(name = "user_course")
    private short course;

    @Column(name = "user_birthdate")
    private Date birthday;

    @Column(name = "user_telegram_username")
    private String telegramUserName;

    @Column(name = "user_join_date")
    private Date joinDate;

    @Column(name = "user_is_active")
    private boolean active;

    public User() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public User(Long id, String login, String password) {
        this.id = id;
        this.login = login;
        this.password = password;
    }

    public User(Long id, String login, String password, String salt) {
        this.id = id;
        this.login = login;
        this.password = password;
        this.salt = salt;
    }

    public User(Long id, String login, String password, String salt, int directionId, int departmentId, String userName, String name, String lastName, String patronymic, short course, Date birthday, String telegramUserName, Date joinDate, boolean active) {
        this.id = id;
        this.login = login;
        this.password = password;
        this.salt = salt;
        this.directionId = directionId;
        this.departmentId = departmentId;
        this.userName = userName;
        this.name = name;
        this.lastName = lastName;
        this.patronymic = patronymic;
        this.course = course;
        this.birthday = birthday;
        this.telegramUserName = telegramUserName;
        this.joinDate = joinDate;
        this.active = active;
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }

    public int getDirectionId() {
        return directionId;
    }

    public void setDirectionId(int directionId) {
        this.directionId = directionId;
    }

    public long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(long departmentId) {
        this.departmentId = departmentId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPatronymic() {
        return patronymic;
    }

    public void setPatronymic(String patronymic) {
        this.patronymic = patronymic;
    }

    public short getCourse() {
        return course;
    }

    public void setCourse(short course) {
        this.course = course;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getTelegramUserName() {
        return telegramUserName;
    }

    public void setTelegramUserName(String telegramUserName) {
        this.telegramUserName = telegramUserName;
    }

    public Date getJoinDate() {
        return joinDate;
    }

    public void setJoinDate(Date joinDate) {
        this.joinDate = joinDate;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}