package com.vsu.student_council_app.mappers;

import com.vsu.student_council_app.Entity.Event;
import com.vsu.student_council_app.dto.EventDTO;
import com.vsu.student_council_app.request.create.CreateEventRequest;
import com.vsu.student_council_app.request.update.UpdateEventRequest;
import org.springframework.stereotype.Component;

@Component
public class EventMapper {
    public EventDTO eventToEventDTO(Event event){
        EventDTO eventDTO = new EventDTO();
        eventDTO.setId(event.getId());
        eventDTO.setEventStatusId(event.getEventStatusId());
        eventDTO.setDepartmentId(event.getDepartmentId());
        eventDTO.setTitle(event.getTitle());
        eventDTO.setDescription(event.getDescription());
        eventDTO.setStartDate(event.getStartDate());
        eventDTO.setEndDate(event.getEndDate());
        eventDTO.setAuditory(event.getAuditory());
        return eventDTO;
    }

    public Event createEventRequestToEvent(CreateEventRequest createEventRequest){
        Event event = new Event();
        event.setEventStatusId(createEventRequest.getEventStatusId());
        event.setDepartmentId(createEventRequest.getDepartmentId());
        event.setTitle(createEventRequest.getTitle());
        event.setDescription(createEventRequest.getDescription());
        event.setStartDate(createEventRequest.getStartDate());
        event.setEndDate(createEventRequest.getEndDate());
        event.setAuditory(createEventRequest.getAuditory());
        return event;
    }
    public Event updateEventRequestToEvent(UpdateEventRequest updateEventRequest){
        Event event = new Event();
        event.setId(updateEventRequest.getId());
        event.setEventStatusId(updateEventRequest.getEventStatusId());
        event.setDepartmentId(updateEventRequest.getDepartmentId());
        event.setTitle(updateEventRequest.getTitle());
        event.setDescription(updateEventRequest.getDescription());
        event.setStartDate(updateEventRequest.getStartDate());
        event.setEndDate(updateEventRequest.getEndDate());
        event.setAuditory(updateEventRequest.getAuditory());
        return event;
    }
}
