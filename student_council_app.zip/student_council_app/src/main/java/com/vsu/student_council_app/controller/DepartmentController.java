package com.vsu.student_council_app.controller;

import com.vsu.student_council_app.dto.DepartmentDTO;
import com.vsu.student_council_app.request.create.CreateDepartmentRequest;
import com.vsu.student_council_app.request.update.UpdateDepartmentRequest;
import com.vsu.student_council_app.service.DepartmentService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/department")
public class DepartmentController {
    private final DepartmentService departmentService;

    public DepartmentController(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    @GetMapping("/{id}")
    public DepartmentDTO getDepartment(@PathVariable Long id) {
        return departmentService.getById(id);
    }

    @PostMapping("")
    public DepartmentDTO createDepartment(@RequestBody CreateDepartmentRequest request) {
        return departmentService.create(request);
    }

    @PutMapping("")
    public DepartmentDTO updateDepartment(@RequestBody UpdateDepartmentRequest request) {
        return departmentService.update(request);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteDepartment(@PathVariable Long id) {
        departmentService.delete(id);
    }
}
