package com.vsu.student_council_app.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import java.sql.Date;

@Entity
@Table(name = "user_in_rank")
public class UserInRank {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_rank_id")
    private Long id;

    @Column(name = "rank_id", nullable = false)
    private Integer rankId;

    @Column(name = "user_rank_start_date", nullable = false)
    private Date startDate;

    @Column(name = "user_rank_end_date")
    private Date endDate;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    public UserInRank() {
    }

    public UserInRank(Long id, Integer rankId, Date startDate, Date endDate, Long userId) {
        this.id = id;
        this.rankId = rankId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.userId = userId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getRankId() {
        return rankId;
    }

    public void setRankId(Integer rankId) {
        this.rankId = rankId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}