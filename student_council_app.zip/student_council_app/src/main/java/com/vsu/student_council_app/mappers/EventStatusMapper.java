package com.vsu.student_council_app.mappers;

import com.vsu.student_council_app.Entity.EventStatus;
import com.vsu.student_council_app.dto.EventStatusDTO;
import com.vsu.student_council_app.request.create.CreateEventStatusRequest;
import com.vsu.student_council_app.request.update.UpdateEventStatusRequest;
import org.springframework.stereotype.Component;

@Component
public class EventStatusMapper {
    public EventStatusDTO eventStatusToEventStatusDTO(EventStatus eventStatus) {
        EventStatusDTO eventStatusDTO = new EventStatusDTO();
        eventStatusDTO.setId(eventStatus.getId());
        eventStatusDTO.setName(eventStatus.getName());
        return eventStatusDTO;
    }

    public EventStatus creteEventStatusRequestToEventStatus(CreateEventStatusRequest createEventStatusRequest) {
        EventStatus eventStatus = new EventStatus();
        eventStatus.setName(createEventStatusRequest.getName());
        return eventStatus;
    }
    public EventStatus updateEventStatusRequestToEventStatus(UpdateEventStatusRequest updateEventStatusRequest) {
        EventStatus eventStatus = new EventStatus();
        eventStatus.setId(updateEventStatusRequest.getId());
        eventStatus.setName(updateEventStatusRequest.getName());
        return eventStatus;
    }
}
