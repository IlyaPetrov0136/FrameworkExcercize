package com.vsu.student_council_app.service;

import com.vsu.student_council_app.Entity.Rank;
import com.vsu.student_council_app.Entity.UserInRank;
import com.vsu.student_council_app.dto.RankDTO;
import com.vsu.student_council_app.dto.UserInRankDTO;
import com.vsu.student_council_app.exception.ValidationException;
import com.vsu.student_council_app.mappers.RankMapper;
import com.vsu.student_council_app.mappers.UserInRankMapper;
import com.vsu.student_council_app.repository.RankRepository;
import com.vsu.student_council_app.repository.UserInRankRepository;
import com.vsu.student_council_app.repository.UserRepository;
import com.vsu.student_council_app.request.create.CreateRankRequest;
import com.vsu.student_council_app.request.create.CreateUserInRankRequest;
import com.vsu.student_council_app.request.update.UpdateRankRequest;
import com.vsu.student_council_app.request.update.UpdateUserInRankRequest;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class RankService {
    private final RankRepository rankRepository;
    private final RankMapper rankMapper;
    private final UserInRankMapper userInRankMapper;
    private  final UserInRankRepository userInRankRepository;
    private final UserRepository userRepository;

    public RankService(RankRepository rankRepository, RankMapper rankMapper, UserInRankMapper userInRankMapper, UserInRankRepository userInRankRepository, UserRepository userRepository) {
        this.rankRepository = rankRepository;
        this.rankMapper = rankMapper;
        this.userInRankMapper = userInRankMapper;
        this.userInRankRepository = userInRankRepository;
        this.userRepository = userRepository;
    }

    public RankDTO create(CreateRankRequest request) {
        if (rankRepository.findByName(request.getName()).isPresent()) {
            throw new ValidationException("Rank with this name already exists");
        }
        Rank rank = rankMapper.createRankRequestToRank(request);
        Rank savedRank = rankRepository.save(rank);
        return rankMapper.rankToRankDTO(savedRank);
    }

    public RankDTO getById(Long id) {
        Rank rank = rankRepository.findById(id)
                .orElseThrow(() -> new ValidationException("Rank not found"));

        return rankMapper.rankToRankDTO(rank);
    }

    public RankDTO update(UpdateRankRequest request) {
        if (rankRepository.findById(request.getId()).isEmpty()) {
            throw new ValidationException("Rank with this id not exists");
        }

        Rank rank = rankMapper.updateRankRequestToRank(request);

        Rank updatedRank = rankRepository.save(rank);
        return rankMapper.rankToRankDTO(updatedRank);
    }

    public void delete(Long id) {
        if (rankRepository.findById(id).isEmpty()) {
            throw new ValidationException("Rank not found");
        }
        rankRepository.deleteById(id);
    }

    public UserInRankDTO createUserInRank(CreateUserInRankRequest request) {
        if(userRepository.findById(request.getUserId()).isEmpty()){
            throw new ValidationException("User with this id not exists");
        }
        if(rankRepository.findById(request.getRankId()).isEmpty()){
            throw new ValidationException("Rank with this id not exists");
        }
        UserInRank userInRank= userInRankMapper.createUserInRankRequestToUserInRank(request);
        UserInRank savedUserInRank = userInRankRepository.save(userInRank);
        return userInRankMapper.userInRankToUserInRankDTO(savedUserInRank);
    }

    public UserInRankDTO updateUserInRank(UpdateUserInRankRequest request) {
        if(userRepository.findById(request.getUserId()).isEmpty()){
            throw new ValidationException("User with this id not exists");
        }
        if(rankRepository.findById(request.getRankId()).isEmpty()){
            throw new ValidationException("Rank with this id not exists");
        }
        UserInRank userInRank= userInRankMapper.updateUserInRankRequestToUserInRank(request);
        UserInRank savedUserInRank = userInRankRepository.save(userInRank);
        return userInRankMapper.userInRankToUserInRankDTO(savedUserInRank);
    }

    public UserInRankDTO getUserInRank(Long id) {
        UserInRank userInRank= userInRankRepository.findUserInRankById(id).orElseThrow(() -> new ValidationException("User with this id not exists"));
        return userInRankMapper.userInRankToUserInRankDTO(userInRank);
    }

    public void deleteUserInRank(Long id) {
        userInRankRepository.deleteById(id);
    }
}
