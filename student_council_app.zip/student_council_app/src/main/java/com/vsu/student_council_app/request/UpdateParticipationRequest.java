package com.vsu.student_council_app.request;

import java.sql.Date;

public class UpdateParticipationRequest {
    private Long id;
    private Integer eventId;
    private int Status;
    private String Reason;
    private Date registeredAt;

    public UpdateParticipationRequest() {
    }

    public UpdateParticipationRequest(Long id, Integer eventId, int status, String reason, Date registeredAt) {
        this.id = id;
        this.eventId = eventId;
        Status = status;
        Reason = reason;
        this.registeredAt = registeredAt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getEventId() {
        return eventId;
    }

    public void setEventId(Integer eventId) {
        this.eventId = eventId;
    }

    public int getStatus() {
        return Status;
    }

    public void setStatus(int status) {
        Status = status;
    }

    public String getReason() {
        return Reason;
    }

    public void setReason(String reason) {
        Reason = reason;
    }

    public Date getRegisteredAt() {
        return registeredAt;
    }

    public void setRegisteredAt(Date registeredAt) {
        this.registeredAt = registeredAt;
    }
}
