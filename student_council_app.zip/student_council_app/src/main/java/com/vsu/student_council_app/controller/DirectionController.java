package com.vsu.student_council_app.controller;

import com.vsu.student_council_app.dto.DirectionDTO;
import com.vsu.student_council_app.request.create.CreateDirectionRequest;
import com.vsu.student_council_app.request.update.UpdateDirectionRequest;
import com.vsu.student_council_app.service.DirectionService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/direction")
public class DirectionController {
    private final DirectionService directionService;

    public DirectionController(DirectionService directionService) {
        this.directionService = directionService;
    }

    @GetMapping("/{id}")
    public DirectionDTO getDirection(@PathVariable int id) {
        return directionService.getById(id);
    }

    @PostMapping("")
    public DirectionDTO createDirection(@RequestBody CreateDirectionRequest request) {
        return directionService.create(request);
    }

    @PutMapping("")
    public DirectionDTO updateDirection(@RequestBody UpdateDirectionRequest request) {
        return directionService.update(request);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteDirection(@PathVariable int id) {
        directionService.delete(id);
    }
}
