package com.vsu.student_council_app.mappers;

import com.vsu.student_council_app.Entity.TaskStatus;
import com.vsu.student_council_app.dto.TaskStatusDTO;
import com.vsu.student_council_app.request.create.CreateTaskStatusRequest;
import com.vsu.student_council_app.request.update.UpdateTaskStatusRequest;
import org.springframework.stereotype.Component;

@Component
public class TaskStatusMapper {
    public TaskStatusDTO taskStatusToTaskStatusDTO(TaskStatus taskStatus) {
        TaskStatusDTO taskStatusDTO = new TaskStatusDTO();
        taskStatusDTO.setId(taskStatus.getId());
        taskStatusDTO.setName(taskStatus.getName());
        return taskStatusDTO;
    }

    public TaskStatus createTaskStatusToTaskStatus(CreateTaskStatusRequest createTaskStatusRequest) {
        TaskStatus taskStatus = new TaskStatus();
        taskStatus.setName(createTaskStatusRequest.getName());
        return taskStatus;
    }

    public TaskStatus updateTaskStatusToTaskStatus(UpdateTaskStatusRequest updateTaskStatusRequest) {
        TaskStatus taskStatus = new TaskStatus();
        taskStatus.setId(updateTaskStatusRequest.getId());
        taskStatus.setName(updateTaskStatusRequest.getName());
        return taskStatus;
    }
}
