package com.vsu.student_council_app.service;

import com.vsu.student_council_app.Entity.Event;
import com.vsu.student_council_app.Entity.EventStatus;
import com.vsu.student_council_app.dto.EventDTO;
import com.vsu.student_council_app.dto.EventStatusDTO;
import com.vsu.student_council_app.exception.ValidationException;
import com.vsu.student_council_app.mappers.EventMapper;
import com.vsu.student_council_app.mappers.EventStatusMapper;
import com.vsu.student_council_app.repository.DepartmentRepository;
import com.vsu.student_council_app.repository.EventRepository;
import com.vsu.student_council_app.repository.EventStatusRepository;
import com.vsu.student_council_app.request.create.CreateEventRequest;
import com.vsu.student_council_app.request.create.CreateEventStatusRequest;
import com.vsu.student_council_app.request.update.UpdateEventRequest;
import com.vsu.student_council_app.request.update.UpdateEventStatusRequest;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class EventService {
    private final EventStatusRepository eventStatusRepository;
    private final EventRepository eventRepository;
    private final EventMapper eventMapper;
    private final EventStatusMapper eventStatusMapper;
    private final DepartmentRepository departmentRepository;

    public EventService(EventStatusRepository eventStatusRepository, EventRepository eventRepository, EventMapper eventMapper, EventStatusMapper eventStatusMapper, DepartmentRepository departmentRepository) {
        this.eventStatusRepository = eventStatusRepository;
        this.eventRepository = eventRepository;
        this.eventMapper = eventMapper;
        this.eventStatusMapper = eventStatusMapper;
        this.departmentRepository = departmentRepository;
    }

    public EventStatusDTO createEventStatus(CreateEventStatusRequest request) {
        if (eventStatusRepository.findByName((request.getName())).isPresent()) {
            throw new ValidationException("Event status with this name already exists");
        }
        EventStatus eventStatus = eventStatusMapper.creteEventStatusRequestToEventStatus(request);
        EventStatus savedEventStatus = eventStatusRepository.save(eventStatus);
        return eventStatusMapper.eventStatusToEventStatusDTO(savedEventStatus);
    }

    public EventStatusDTO getEventStatusById(Long id) {
        EventStatus eventStatus = eventStatusRepository.findById(id)
                .orElseThrow(() -> new ValidationException("Event status not found"));

        return eventStatusMapper.eventStatusToEventStatusDTO(eventStatus);
    }

    public EventStatusDTO updateEventStatus(UpdateEventStatusRequest request) {
        if(eventStatusRepository.findById((request.getId())).isEmpty()) {
            throw new ValidationException("Event status with this id not exists");
        }

        EventStatus eventStatus=  eventStatusMapper.updateEventStatusRequestToEventStatus(request);

        EventStatus updatedEventStatus = eventStatusRepository.save(eventStatus);
        return eventStatusMapper.eventStatusToEventStatusDTO(updatedEventStatus);
    }

    public void deleteEventStatus(Long id) {
        if (eventStatusRepository.findById(id).isEmpty()) {
            throw new ValidationException("Event status not found");
        }
        eventStatusRepository.deleteById(id);
    }



    public EventDTO createEvent(CreateEventRequest request) {
        if (eventRepository.findByTitle(request.getTitle()).isPresent()) {
            throw new ValidationException("Event with this title already exists");
        }
        if (departmentRepository.findById(request.getDepartmentId()).isEmpty()) {
            throw new ValidationException("Department not found");
        }
        if (eventStatusRepository.findById(request.getEventStatusId()).isEmpty()) {
            throw new ValidationException("Event status not found");
        }

        Event event = eventMapper.createEventRequestToEvent(request);
        Event savedEvent = eventRepository.save(event);
        return eventMapper.eventToEventDTO(savedEvent);
    }

    public EventDTO getEventById(Long id) {
        Event event = eventRepository.findById(id)
                .orElseThrow(() -> new ValidationException("Event not found"));
        return eventMapper.eventToEventDTO(event);
    }

    public EventDTO updateEvent(UpdateEventRequest request) {
        eventRepository.findById(request.getId()).orElseThrow(() -> new ValidationException("Event not found"));

        if (departmentRepository.findById(request.getDepartmentId()).isEmpty()) {
            throw new ValidationException("Department not found");
        }
        if (eventStatusRepository.findById(request.getEventStatusId()).isEmpty()) {
            throw new ValidationException("Event status not found");
        }
        Event updatedEvent = eventRepository.save(eventMapper.updateEventRequestToEvent(request));
        return eventMapper.eventToEventDTO(updatedEvent);
    }

    public void deleteEvent(Long id) {
        if (eventRepository.findById(id).isEmpty()) {
            throw new ValidationException("Event not found");
        }
        eventRepository.deleteById(id);
    }
}
