package com.vsu.student_council_app.mappers;

import com.vsu.student_council_app.Entity.User;
import com.vsu.student_council_app.dto.UserDTO;
import com.vsu.student_council_app.request.create.CreateUserRequest;
import com.vsu.student_council_app.request.update.UpdateUserRequest;
import org.springframework.stereotype.Component;

@Component
public class UserMapper {

    public UserDTO toUserDTO(User user) {
        return new UserDTO(
                user.getId(),
                user.getLogin(),
                user.getDirectionId(),
                user.getDepartmentId(),
                user.getUserName(),
                user.getName(),
                user.getLastName(),
                user.getPatronymic(),
                user.getCourse(),
                user.getBirthday(),
                user.getTelegramUserName(),
                user.getJoinDate(),
                user.isActive()
        );
    }

    public User createRequestToUser(CreateUserRequest request) {
        User user = new User();
        user.setLogin(request.getLogin());
        user.setPassword(request.getPassword());
        user.setDirectionId(request.getDirectionId());
        user.setDepartmentId(request.getDepartmentId());
        user.setUserName(request.getUserName());
        user.setName(request.getName());
        user.setLastName(request.getLastName());
        user.setPatronymic(request.getPatronymic());
        user.setCourse(request.getCourse());
        user.setBirthday(request.getBirthday());
        user.setTelegramUserName(request.getTelegramUserName());
        user.setJoinDate(request.getJoinDate());
        user.setActive(request.isActive());
        return user;
    }

    public User updateUsertoUser(UpdateUserRequest request) {
        User user = new User();
        user.setId(request.getId());
        user.setLogin(request.getLogin());
        user.setDirectionId(request.getDirectionId());
        user.setDepartmentId(request.getDepartmentId());
        user.setUserName(request.getUserName());
        user.setName(request.getName());
        user.setLastName(request.getLastName());
        user.setPatronymic(request.getPatronymic());
        user.setCourse(request.getCourse());
        user.setBirthday(request.getBirthday());
        user.setTelegramUserName(request.getTelegramUserName());
        user.setJoinDate(request.getJoinDate());
        user.setActive(request.isActive());
        return user;
    }
}