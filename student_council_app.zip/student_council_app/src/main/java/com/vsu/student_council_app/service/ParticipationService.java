package com.vsu.student_council_app.service;

import com.vsu.student_council_app.Entity.Participation;
import com.vsu.student_council_app.Entity.User;
import com.vsu.student_council_app.dto.ParticipationDTO;
import com.vsu.student_council_app.dto.ParticipationStatusDTO;
import com.vsu.student_council_app.exception.NotFoundException;
import com.vsu.student_council_app.exception.RepositoryException;
import com.vsu.student_council_app.exception.ValidationException;
import com.vsu.student_council_app.mappers.ParticipationMapper;
import com.vsu.student_council_app.mappers.ParticipationStatusMapper;
import com.vsu.student_council_app.repository.EventRepository;
import com.vsu.student_council_app.repository.ParticipationRepository;
import com.vsu.student_council_app.repository.ParticipationStatusRepository;
import com.vsu.student_council_app.repository.UserRepository;
import com.vsu.student_council_app.request.create.CreateParticipationRequest;
import com.vsu.student_council_app.request.create.CreateParticipationStatusRequest;
import com.vsu.student_council_app.request.update.UpdateParticipationRequest;
import com.vsu.student_council_app.request.update.UpdateParticipationStatusRequest;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ParticipationService {
    private final UserRepository userRepository;
    private final ParticipationRepository participationRepository;
    private final ParticipationMapper participationMapper;
    private final ParticipationStatusRepository participationStatusRepository;
    private final ParticipationStatusMapper participationStatusMapper;
    private final EventRepository eventRepository;

    public ParticipationService(UserRepository userRepository, ParticipationRepository participationRepository, ParticipationMapper participationMapper, ParticipationStatusRepository participationStatusRepository, ParticipationStatusMapper participationStatusMapper, EventRepository eventRepository) {
        this.userRepository = userRepository;
        this.participationRepository = participationRepository;
        this.participationMapper = participationMapper;
        this.participationStatusRepository = participationStatusRepository;
        this.participationStatusMapper = participationStatusMapper;
        this.eventRepository = eventRepository;
    }
    public ParticipationDTO createParticipation(@Valid CreateParticipationRequest request) {
        Optional<User> user = userRepository.findByID(request.getUserId());
        if (user.isEmpty()) {
            throw new NotFoundException("User not found");
        }
        if(!eventRepository.existsById(Long.valueOf(request.getEventId()))){
            throw new NotFoundException("Event not found");
        }
        if(userRepository.findByID(request.getUserId()).isEmpty()){
            throw new NotFoundException("User not found");
        }

        try {
            Participation participation = new Participation(
                    null,
                    request.getUserId(),
                    request.getEventId(),
                    request.getStatus(),
                    request.getReason(),
                    request.getRegisteredAt()
            );

            Long id = participationRepository.create(participation);
            if (id != null && id != 0) {
                participation.setId(id);
                return participationMapper.toParticipationDTO(participation);
            }
            throw new ValidationException("Failed to create participation");
        } catch (DataAccessException e) {
            throw new RepositoryException("Error accessing data" + e.getMessage());
        }
    }

    public ParticipationDTO updateParticipation(@Valid UpdateParticipationRequest request) {
        Optional<User> user = userRepository.findByID(request.getUserId());
        if (user.isEmpty()) {
            throw new NotFoundException("User not found");
        }

        try {
            Participation participation = new Participation(
                    request.getId(),
                    request.getUserId(),
                    request.getEventId(),
                    request.getStatus(),
                    request.getReason(),
                    request.getRegisteredAt()
            );

            int result = participationRepository.update(participation);
            if (result == 1) {
                return participationMapper.toParticipationDTO(
                        participationRepository.findById(request.getId())
                                .orElseThrow(() -> new NotFoundException("Updated participation not found"))
                );
            }
            throw new ValidationException("Failed to update participation");

        } catch (DataAccessException e) {
            throw new RepositoryException("Error accessing data" + e);
        }
    }

    public ParticipationDTO findParticipationById(long id) {
        Participation participation = participationRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Participation not found"));

        return participationMapper.toParticipationDTO(participation);
    }

    public List<ParticipationDTO> findParticipationsByUser(long userId) {
        userRepository.findByID(userId)
                .orElseThrow(() -> new NotFoundException("User not found"));

        List<Participation> participations = participationRepository.findByUserId(userId)
                .orElseThrow(() -> new NotFoundException("No participations found"));

        List<ParticipationDTO> result = new ArrayList<>();
        for (Participation p : participations) {
            result.add(participationMapper.toParticipationDTO(p));
        }
        return result;
    }

    public List<ParticipationDTO> findParticipationsByEvent(int eventId) {
        List<Participation> participations = participationRepository.findByEventId(eventId)
                .orElseThrow(() -> new NotFoundException("No participations found for this event"));

        List<ParticipationDTO> result = new ArrayList<>();
        for (Participation p : participations) {
            result.add(participationMapper.toParticipationDTO(p));
        }
        return result;
    }
    public List<ParticipationDTO> findParticipationsByReason(String reason) {
        List<Participation> participations = participationRepository.findByReason(reason)
                .orElseThrow(() -> new NotFoundException("No participations found with this reason"));

        List<ParticipationDTO> result = new ArrayList<>();
        for (Participation p : participations) {
            result.add(participationMapper.toParticipationDTO(p));
        }
        return result;
    }

    public void deleteParticipation(long id) {
        if (participationRepository.deleteById(id) != 1) {
            throw new RepositoryException("Failed to delete participation");
        }
    }
    public ParticipationStatusDTO createParticipationStatus(CreateParticipationStatusRequest createParticipationStatusRequest){
        if (participationStatusRepository.findByName(createParticipationStatusRequest.getName()) !=null){
            throw new ValidationException("Participation already exists");
        }
        return participationStatusMapper.participationStatusToParticipationStatusDTO(participationStatusRepository.save(participationStatusMapper.creteParticipationStatusToParticipationStatus(createParticipationStatusRequest)));
    }

    public ParticipationStatusDTO findParticipationStatusById(Long id) {
        return participationStatusMapper.participationStatusToParticipationStatusDTO(participationStatusRepository.getReferenceById(id));
    }

    public ParticipationStatusDTO updateParticipationStatus(UpdateParticipationStatusRequest updateParticipationStatusRequest) {
        if(participationStatusRepository.getReferenceById(updateParticipationStatusRequest.getId())==null){
            throw new NotFoundException("Participation status does not exist");
        }
        return participationStatusMapper.participationStatusToParticipationStatusDTO( participationStatusRepository.save(participationStatusMapper.updateParticipationStatusToParticipationStatus(updateParticipationStatusRequest)));
    }
    public void deleteParticipationStatus(long id) {
        if(participationStatusRepository.getReferenceById(id)==null){
            throw new NotFoundException("Participation status does not exist");
        }
        participationStatusRepository.deleteById(id);
    }
}
