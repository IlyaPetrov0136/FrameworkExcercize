package com.vsu.student_council_app.handler;


import com.vsu.student_council_app.exception.NotFoundException;
import com.vsu.student_council_app.exception.RepositoryException;
import com.vsu.student_council_app.exception.ValidationException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.logging.Level;
import java.util.logging.Logger;

@ControllerAdvice
public class ProfileControllerAdvice {
    private final static Logger LOGGER =  Logger.getLogger(ProfileControllerAdvice.class.getName());

    @ExceptionHandler(NotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public void handleNotFound(NotFoundException e){
        LOGGER.log(Level.WARNING,"not found exception",e);
    }

    @ExceptionHandler(ValidationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public void handleValidation(ValidationException e){
        LOGGER.log(Level.WARNING,"validation exception",e);
    }


    @ExceptionHandler(RepositoryException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public void handleRepositoryException(RepositoryException e){LOGGER.log(Level.WARNING,"repository exception",e);}
}
