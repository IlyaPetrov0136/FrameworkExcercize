package com.vsu.student_council_app.service;

import com.vsu.student_council_app.Entity.Direction;
import com.vsu.student_council_app.dto.DirectionDTO;
import com.vsu.student_council_app.exception.ValidationException;
import com.vsu.student_council_app.mappers.DirectionMapper;
import com.vsu.student_council_app.repository.DirectionRepository;
import com.vsu.student_council_app.request.create.CreateDirectionRequest;
import com.vsu.student_council_app.request.update.UpdateDirectionRequest;
import jakarta.transaction.Transactional;

import org.springframework.stereotype.Service;

@Service
@Transactional
public class DirectionService {
    private final DirectionRepository directionRepository;
    private final DirectionMapper directionMapper;

    public DirectionService(DirectionRepository directionRepository, DirectionMapper directionMapper) {
        this.directionRepository = directionRepository;
        this.directionMapper = directionMapper;
    }

    public DirectionDTO create(CreateDirectionRequest request) {
        if (directionRepository.findByName((request.getName())).isPresent()) {
            throw new ValidationException("Direction already exists");
        }

        Direction direction = directionMapper.createRequestToDirection(request);
        Direction savedDirection = directionRepository.save(direction);
        return directionMapper.directionToDirectionDTO(savedDirection);
    }

    public DirectionDTO getById(int id) {
        if (directionRepository.findById(id).isEmpty()) {
            throw new ValidationException("Direction not exists");
        }

        return directionMapper.directionToDirectionDTO(directionRepository.getReferenceById(id));
    }

    public DirectionDTO update(UpdateDirectionRequest request) {
        if (directionRepository.findById(request.getId()).isEmpty()) {
            throw new ValidationException("Direction not exists");
        }
        Direction direction = directionMapper.updateRequestToDirection(request);
        Direction savedDirection = directionRepository.save(direction);
        return directionMapper.directionToDirectionDTO(savedDirection);
    }

    public void delete(int id) {
        if (directionRepository.findById(id).isEmpty()) {
            throw new ValidationException("Direction not exists");
        }
        directionRepository.deleteById(id);
    }
}
