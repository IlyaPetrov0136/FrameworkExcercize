package com.vsu.student_council_app.repository;

import com.vsu.student_council_app.Entity.ParticipationStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ParticipationStatusRepository extends JpaRepository<ParticipationStatus, Integer> {
    public ParticipationStatus findByName(String name);

    public ParticipationStatus getReferenceById(Long id);

    void deleteById(Long id);
}
