package com.vsu.student_council_app.controller;

import com.vsu.student_council_app.dto.TaskCommentDTO;
import com.vsu.student_council_app.dto.TaskDTO;
import com.vsu.student_council_app.dto.TaskStatusDTO;
import com.vsu.student_council_app.request.create.CreateTaskCommentRequest;
import com.vsu.student_council_app.request.create.CreateTaskRequest;
import com.vsu.student_council_app.request.create.CreateTaskStatusRequest;
import com.vsu.student_council_app.request.update.UpdateTaskCommentRequest;
import com.vsu.student_council_app.request.update.UpdateTaskRequest;
import com.vsu.student_council_app.request.update.UpdateTaskStatusRequest;
import com.vsu.student_council_app.service.TaskService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/task")
public class TaskController {
    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @GetMapping("/{id}")
    public TaskDTO getTask(@PathVariable Long id) {
        return taskService.getTaskById(id);
    }

    @PostMapping("")
    public TaskDTO createTask(@RequestBody CreateTaskRequest request) {
        return taskService.createTask(request);
    }

    @PutMapping("")
    public TaskDTO updateTask(@RequestBody UpdateTaskRequest request) {
        return taskService.updateTask(request);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteTask(@PathVariable Long id) {
        taskService.deleteTask(id);
    }

    @GetMapping("/status/{id}")
    public TaskStatusDTO getTaskStatus(@PathVariable Long id) {
        return taskService.getTaskStatusById(id);
    }

    @PostMapping("/status")
    public TaskStatusDTO createTaskStatus(@RequestBody CreateTaskStatusRequest request) {
        return taskService.createTaskStatus(request);
    }

    @PutMapping("/status")
    public TaskStatusDTO updateTaskStatus(@RequestBody UpdateTaskStatusRequest request) {
        return taskService.updateTaskStatus(request);
    }

    @DeleteMapping("/status/delete/{id}")
    public void deleteTaskStatus(@PathVariable Long id) {
        taskService.deleteTaskStatus(id);
    }

    @GetMapping("/comment/{id}")
    public TaskCommentDTO getTaskComment(@PathVariable Long id) {
        return taskService.getTaskCommentById(id);
    }

    @PostMapping("/comment")
    public TaskCommentDTO createTaskComment(@RequestBody CreateTaskCommentRequest request) {
        return taskService.createTaskComment(request);
    }

    @PutMapping("/comment")
    public TaskCommentDTO updateTaskComment(@RequestBody UpdateTaskCommentRequest request) {
        return taskService.updateTaskComment(request);
    }

    @DeleteMapping("/comment/delete/{id}")
    public void deleteTaskComment(@PathVariable Long id) {
        taskService.deleteTaskComment(id);
    }
}
