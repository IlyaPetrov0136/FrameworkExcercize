package com.vsu.student_council_app.mappers;

import com.vsu.student_council_app.Entity.ParticipationStatus;
import com.vsu.student_council_app.dto.ParticipationStatusDTO;
import com.vsu.student_council_app.request.create.CreateParticipationStatusRequest;
import com.vsu.student_council_app.request.update.UpdateParticipationStatusRequest;
import org.springframework.stereotype.Component;

@Component
public class ParticipationStatusMapper {
    public ParticipationStatusDTO participationStatusToParticipationStatusDTO(ParticipationStatus ps) {
        ParticipationStatusDTO psDTO = new ParticipationStatusDTO();
        psDTO.setId(ps.getId());
        psDTO.setName(ps.getName());
        return psDTO;
    }
    public ParticipationStatus creteParticipationStatusToParticipationStatus(CreateParticipationStatusRequest psRequest) {
        ParticipationStatus ps = new ParticipationStatus();
        ps.setName(psRequest.getName());
        return ps;
    }
    public ParticipationStatus updateParticipationStatusToParticipationStatus(UpdateParticipationStatusRequest psRequest) {
        ParticipationStatus ps = new ParticipationStatus();
        ps.setId(psRequest.getId());
        ps.setName(psRequest.getName());
        return ps;
    }
}
