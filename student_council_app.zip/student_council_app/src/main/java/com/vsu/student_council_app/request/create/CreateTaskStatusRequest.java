package com.vsu.student_council_app.request.create;

public class CreateTaskStatusRequest {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
