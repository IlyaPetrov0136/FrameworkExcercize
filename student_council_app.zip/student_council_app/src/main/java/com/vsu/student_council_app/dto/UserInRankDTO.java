package com.vsu.student_council_app.dto;

import java.sql.Date;

public class UserInRankDTO {
    private Long id;
    private Integer rankId;
    private Date startDate;
    private Date endDate;
    private Long userId;

    public UserInRankDTO() {
    }

    public UserInRankDTO(Long id, Integer rankId, Date startDate, Date endDate, Long userId) {
        this.id = id;
        this.rankId = rankId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.userId = userId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getRankId() {
        return rankId;
    }

    public void setRankId(Integer rankId) {
        this.rankId = rankId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}