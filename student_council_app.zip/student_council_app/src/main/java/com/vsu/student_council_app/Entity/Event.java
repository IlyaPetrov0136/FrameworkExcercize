package com.vsu.student_council_app.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.sql.Date;

@Entity
@Table(name = "events")
public class Event {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "event_id")
    private long id;

    @Column(name = "department_id", nullable = false)
    private long departmentId;

    @Column(name = "event_status_id", nullable = false)
    private long eventStatusId;

    @Column(name = "event_title", nullable = false)
    private String title;

    @Column(name = "event_description", nullable = false)
    private String description;

    @Column(name = "event_start", nullable = false)
    private Date startDate;

    @Column(name = "event_end")
    private Date endDate;

    @Column(name = "event_audithory")
    private Short auditory;

    public Event() {
    }

    public Event(int id, Integer departmentId, Integer eventStatusId, String title, String description, Date startDate, Date endDate, Short auditory) {
        this.id = id;
        this.departmentId = departmentId;
        this.eventStatusId = eventStatusId;
        this.title = title;
        this.description = description;
        this.startDate = startDate;
        this.endDate = endDate;
        this.auditory = auditory;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(long departmentId) {
        this.departmentId = departmentId;
    }

    public long getEventStatusId() {
        return eventStatusId;
    }

    public void setEventStatusId(long eventStatusId) {
        this.eventStatusId = eventStatusId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Short getAuditory() {
        return auditory;
    }

    public void setAuditory(Short auditory) {
        this.auditory = auditory;
    }
}