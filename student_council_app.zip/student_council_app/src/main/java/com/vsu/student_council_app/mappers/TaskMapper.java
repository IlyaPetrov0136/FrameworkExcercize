package com.vsu.student_council_app.mappers;

import com.vsu.student_council_app.Entity.Task;
import com.vsu.student_council_app.dto.TaskDTO;
import com.vsu.student_council_app.request.create.CreateTaskRequest;
import com.vsu.student_council_app.request.update.UpdateTaskRequest;
import org.springframework.stereotype.Component;

@Component
public class TaskMapper {
    public TaskDTO taskToTaskDTO(Task task) {
        TaskDTO taskDTO = new TaskDTO();
        taskDTO.setId(task.getId());
        taskDTO.setEventId(task.getEventId());
        taskDTO.setTaskStatusId(task.getTaskStatusId());
        taskDTO.setUserId(task.getUserId());
        taskDTO.setTitle(task.getTitle());
        taskDTO.setDescription(task.getDescription());
        return taskDTO;
    }
    public Task creteTaskRequestToTask(CreateTaskRequest createTaskRequest) {
        Task task = new Task();
        task.setEventId(createTaskRequest.getEventId());
        task.setTaskStatusId(createTaskRequest.getTaskStatusId());
        task.setUserId(createTaskRequest.getUserId());
        task.setTitle(createTaskRequest.getTitle());
        task.setDescription(createTaskRequest.getDescription());
        return task;
    }
    public Task updateTaskRequestToTask(UpdateTaskRequest updateTaskRequest) {
        Task task = new Task();
        task.setId(updateTaskRequest.getId());
        task.setEventId(updateTaskRequest.getEventId());
        task.setTaskStatusId(updateTaskRequest.getTaskStatusId());
        task.setUserId(updateTaskRequest.getUserId());
        task.setTitle(updateTaskRequest.getTitle());
        task.setDescription(updateTaskRequest.getDescription());
        return task;
    }
}
