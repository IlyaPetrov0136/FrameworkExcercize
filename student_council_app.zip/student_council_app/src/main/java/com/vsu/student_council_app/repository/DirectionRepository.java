package com.vsu.student_council_app.repository;

import com.vsu.student_council_app.Entity.Direction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface DirectionRepository extends JpaRepository<Direction, Integer> {
    Direction getByName(String name);

    Optional<Direction>  findById(Long id);

    Optional<Direction> findByName(String name);
}
