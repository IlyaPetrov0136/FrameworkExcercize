package com.vsu.student_council_app.repository;

import com.vsu.student_council_app.Entity.Participation;
import jakarta.validation.Valid;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class ParticipationRepository {
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public ParticipationRepository(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    private Participation mapRowToParticipation(ResultSet rs) throws SQLException {
        return new Participation(
                rs.getLong("participation_id"),
                rs.getLong("user_id"),
                rs.getInt("event_id"),
                rs.getInt("participation_status_id"),
                rs.getString("participation_reason"),
                rs.getDate("participation_registered_at")
        );
    }

    public Long create(@Valid Participation participation) {
        return namedParameterJdbcTemplate.queryForObject(
                "INSERT INTO participation(event_id, user_id, participation_status_id, " +
                        "participation_reason, participation_registered_at) " +
                        "VALUES (:eventId, :userId, :statusId, :reason, :registeredAt) " +
                        "RETURNING participation_id",
                Map.of(
                        "eventId", participation.getEventId(),
                        "userId", participation.getUserId(),
                        "statusId", participation.getStatus(),
                        "reason", participation.getReason() != null ? participation.getReason() : "",
                        "registeredAt", participation.getRegisteredAt()
                ),
                Long.class
        );
    }

    public int update(@Valid Participation participation) {
        return namedParameterJdbcTemplate.update(
                "UPDATE participation SET " +
                        "event_id = :eventId, " +
                        "user_id = :userId, " +
                        "participation_status_id = :statusId, " +
                        "participation_reason = :reason, " +
                        "participation_registered_at = :registeredAt " +
                        "WHERE participation_id = :id ",
                Map.of(
                        "eventId", participation.getEventId(),
                        "userId", participation.getUserId(),
                        "statusId", participation.getStatus(),
                        "reason", participation.getReason() != null ? participation.getReason() : "",
                        "registeredAt", participation.getRegisteredAt(),
                        "id", participation.getId()
                )
        );
    }

    public Optional<Participation> findById(Long id) {
        return namedParameterJdbcTemplate.query(
                "SELECT * FROM participation WHERE participation_id = :id",
                Map.of("id", id),
                rs -> rs.next() ? Optional.of(mapRowToParticipation(rs)) : Optional.empty()
        );
    }

    public Optional<List<Participation>> findByUserId(Long userId) {
        List<Participation> participations = namedParameterJdbcTemplate.query(
                "SELECT * FROM participation WHERE user_id = :userId",
                Map.of("userId", userId),
                (rs, rowNum) -> mapRowToParticipation(rs)
        );

        return participations.isEmpty() ? Optional.empty() : Optional.of(participations);
    }

    public Optional<List<Participation>> findByReason(String reason) {
        List<Participation> participations = namedParameterJdbcTemplate.query(
                "SELECT * FROM participation WHERE participation_reason LIKE :reason",
                Map.of("reason", "%" + reason + "%"),
                (rs, rowNum) -> mapRowToParticipation(rs)
        );

        return participations.isEmpty() ? Optional.empty() : Optional.of(participations);
    }

    public Optional<List<Participation>> findByEventId(Integer eventId) {
        List<Participation> participations = namedParameterJdbcTemplate.query(
                "SELECT * FROM participation WHERE event_id = :eventId",
                Map.of("eventId", eventId),
                (rs, rowNum) -> mapRowToParticipation(rs)
        );

        return participations.isEmpty() ? Optional.empty() : Optional.of(participations);
    }

    public int deleteById(Long id) {
        return namedParameterJdbcTemplate.update(
                "DELETE FROM participation WHERE participation_id = :id",
                Map.of("id", id)
        );
    }
}