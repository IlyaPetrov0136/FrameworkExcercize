package com.vsu.student_council_app.service;

import com.vsu.student_council_app.Entity.Task;
import com.vsu.student_council_app.Entity.TaskComment;
import com.vsu.student_council_app.Entity.TaskStatus;
import com.vsu.student_council_app.dto.TaskCommentDTO;
import com.vsu.student_council_app.dto.TaskDTO;
import com.vsu.student_council_app.dto.TaskStatusDTO;
import com.vsu.student_council_app.exception.ValidationException;
import com.vsu.student_council_app.mappers.TaskCommentMapper;
import com.vsu.student_council_app.mappers.TaskMapper;
import com.vsu.student_council_app.mappers.TaskStatusMapper;
import com.vsu.student_council_app.repository.EventRepository;
import com.vsu.student_council_app.repository.TaskCommentRepository;
import com.vsu.student_council_app.repository.TaskRepository;
import com.vsu.student_council_app.repository.TaskStatusRepository;
import com.vsu.student_council_app.repository.UserRepository;
import com.vsu.student_council_app.request.create.CreateTaskCommentRequest;
import com.vsu.student_council_app.request.create.CreateTaskRequest;
import com.vsu.student_council_app.request.create.CreateTaskStatusRequest;
import com.vsu.student_council_app.request.update.UpdateTaskCommentRequest;
import com.vsu.student_council_app.request.update.UpdateTaskRequest;
import com.vsu.student_council_app.request.update.UpdateTaskStatusRequest;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class TaskService {
    private final TaskRepository taskRepository;
    private final UserRepository userRepository;
    private final TaskStatusRepository taskStatusRepository;
    private final TaskCommentRepository taskCommentRepository;
    private final EventRepository eventRepository;
    private final TaskMapper taskMapper;
    private final TaskStatusMapper taskStatusMapper;
    private final TaskCommentMapper taskCommentMapper;

    public TaskService(TaskRepository taskRepository, UserRepository userRepository, TaskStatusRepository taskStatusRepository, TaskCommentRepository taskCommentRepository, EventRepository eventRepository, TaskMapper taskMapper, TaskStatusMapper taskStatusMapper, TaskCommentMapper taskCommentMapper) {
        this.taskRepository = taskRepository;
        this.userRepository = userRepository;
        this.taskStatusRepository = taskStatusRepository;
        this.taskCommentRepository = taskCommentRepository;
        this.eventRepository = eventRepository;
        this.taskMapper = taskMapper;
        this.taskStatusMapper = taskStatusMapper;
        this.taskCommentMapper = taskCommentMapper;
    }

    public TaskStatusDTO createTaskStatus(CreateTaskStatusRequest request) {
        if (taskStatusRepository.findByName(request.getName()).isPresent()) {
            throw new ValidationException("Task status with this name already exists");
        }
        TaskStatus taskStatus = taskStatusMapper.createTaskStatusToTaskStatus(request);
        TaskStatus savedTaskStatus = taskStatusRepository.save(taskStatus);
        return taskStatusMapper.taskStatusToTaskStatusDTO(savedTaskStatus);
    }

    public TaskStatusDTO getTaskStatusById(Long id) {
        TaskStatus taskStatus = taskStatusRepository.findById(id)
                .orElseThrow(() -> new ValidationException("Task status not found"));
        return taskStatusMapper.taskStatusToTaskStatusDTO(taskStatus);
    }

    public TaskStatusDTO updateTaskStatus(UpdateTaskStatusRequest request) {
        if (taskStatusRepository.findById(request.getId()).isEmpty()) {
            throw new ValidationException("Task status not found");
        }
        TaskStatus updatedTaskStatus = taskStatusRepository.save(taskStatusMapper.updateTaskStatusToTaskStatus(request));
        return taskStatusMapper.taskStatusToTaskStatusDTO(updatedTaskStatus);
    }

    public void deleteTaskStatus(Long id) {
        if (taskStatusRepository.findById(id).isEmpty()) {
            throw new ValidationException("Task status not found");
        }
        taskStatusRepository.deleteById(id);
    }

    // --- CRUD для Task ---
    public TaskDTO createTask(CreateTaskRequest request) {
        if (taskRepository.findByTitle(request.getTitle()).isPresent()) {
            throw new ValidationException("Task with this title already exists");
        }
        if (eventRepository.findById(request.getEventId()).isEmpty()) {
            throw new ValidationException("Event not found");
        }
        if (taskStatusRepository.findById(request.getTaskStatusId()).isEmpty()) {
            throw new ValidationException("Task status not found");
        }
        if (userRepository.findById(request.getUserId()).isEmpty()) {
            throw new ValidationException("User not found");
        }

        Task task = taskMapper.creteTaskRequestToTask(request);
        Task savedTask = taskRepository.save(task);
        return taskMapper.taskToTaskDTO(savedTask);
    }

    public TaskDTO getTaskById(Long id) {
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new ValidationException("Task not found"));
        return taskMapper.taskToTaskDTO(task);
    }

    public TaskDTO updateTask(UpdateTaskRequest request) {
        if (taskRepository.findById(request.getId()).isEmpty()) {
            throw new ValidationException("Task not found");
        }
        if (eventRepository.findById(request.getEventId()).isEmpty()) {
            throw new ValidationException("Event not found");
        }
        if (taskStatusRepository.findById(request.getTaskStatusId()).isEmpty()) {
            throw new ValidationException("Task status not found");
        }
        if (request.getUserId() != null && userRepository.findById(request.getUserId()).isEmpty()) {
            throw new ValidationException("User not found");
        }
        Task updatedTask = taskRepository.save(taskMapper.updateTaskRequestToTask(request));
        return taskMapper.taskToTaskDTO(updatedTask);
    }

    public void deleteTask(Long id) {
        if (taskRepository.findById(id).isEmpty()) {
            throw new ValidationException("Task not found");
        }
        taskRepository.deleteById(id);
    }

    // --- CRUD для TaskComment ---
    public TaskCommentDTO createTaskComment(CreateTaskCommentRequest request) {
        if (taskRepository.findById(request.getTaskId()).isEmpty()) {
            throw new ValidationException("Task not found");
        }
        if (userRepository.findById(request.getUserId()).isEmpty()) {
            throw new ValidationException("User not found");
        }

        TaskComment taskComment = taskCommentMapper.createTaskCommentRequestToTaskComment(request);
        TaskComment savedTaskComment = taskCommentRepository.save(taskComment);
        return taskCommentMapper.taskCommentToTaskCommentDTO(savedTaskComment);
    }

    public TaskCommentDTO getTaskCommentById(Long id) {
        TaskComment taskComment = taskCommentRepository.findById(id)
                .orElseThrow(() -> new ValidationException("Task comment not found"));
        return taskCommentMapper.taskCommentToTaskCommentDTO(taskComment);
    }

    public TaskCommentDTO updateTaskComment(UpdateTaskCommentRequest request) {
        if (taskCommentRepository.findById(request.getId()).isEmpty()) {
            throw new ValidationException("Task comment not found");
        }
        if (taskRepository.findById(request.getTaskId()).isEmpty()) {
            throw new ValidationException("Task not found");
        }
        if (userRepository.findById(request.getUserId()).isEmpty()) {
            throw new ValidationException("User not found");
        }
        TaskComment updatedTaskComment = taskCommentRepository.save(taskCommentMapper.updateTaskCommentRequestToTaskComment(request));
        return taskCommentMapper.taskCommentToTaskCommentDTO(updatedTaskComment);
    }

    public void deleteTaskComment(Long id) {
        if (taskCommentRepository.findById(id).isEmpty()) {
            throw new ValidationException("Task comment not found");
        }
        taskCommentRepository.deleteById(id);
    }
}
