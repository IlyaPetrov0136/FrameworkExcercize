package com.vsu.student_council_app.mappers;

import com.vsu.student_council_app.Entity.Rank;
import com.vsu.student_council_app.dto.RankDTO;
import com.vsu.student_council_app.request.create.CreateRankRequest;
import com.vsu.student_council_app.request.update.UpdateRankRequest;
import org.springframework.stereotype.Component;

@Component
public class RankMapper {
    public RankDTO rankToRankDTO(Rank rank) {
        RankDTO rankDTO = new RankDTO();
        rankDTO.setId(rank.getId());
        rankDTO.setName(rank.getName());
        return rankDTO;
    }
    public Rank createRankRequestToRank(CreateRankRequest createRankRequest) {
        Rank rank = new Rank();
        rank.setName(createRankRequest.getName());
        return rank;
    }
    public Rank updateRankRequestToRank(UpdateRankRequest updateRankRequest) {
        Rank rank = new Rank();
        rank.setId(updateRankRequest.getId());
        rank.setName(updateRankRequest.getName());
        return rank;
    }
}
