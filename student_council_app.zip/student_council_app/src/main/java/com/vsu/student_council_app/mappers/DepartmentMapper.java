package com.vsu.student_council_app.mappers;

import com.vsu.student_council_app.Entity.Department;
import com.vsu.student_council_app.dto.DepartmentDTO;
import com.vsu.student_council_app.request.create.CreateDepartmentRequest;
import com.vsu.student_council_app.request.update.UpdateDepartmentRequest;
import org.springframework.stereotype.Component;

@Component
public class DepartmentMapper {
    public DepartmentDTO departmentToDepartmentDTO(Department department) {
        DepartmentDTO departmentDTO = new DepartmentDTO();
        departmentDTO.setId(department.getId());
        departmentDTO.setName(department.getName());
        return departmentDTO;
    }
    public Department createDepartmentRequestToDepartment(CreateDepartmentRequest createDepartmentRequest) {
        Department department = new Department();
        department.setName(createDepartmentRequest.getName());
        return department;
    }
    public Department updateDepartmentRequestToDepartment(UpdateDepartmentRequest updateDepartmentRequest) {
        Department department = new Department();
        department.setId(updateDepartmentRequest.getId());
        department.setName(updateDepartmentRequest.getName());
        return department;
    }
}
