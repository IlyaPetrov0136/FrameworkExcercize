package com.vsu.student_council_app.controller;


import com.vsu.student_council_app.dto.ParticipationDTO;
import com.vsu.student_council_app.dto.ParticipationStatusDTO;
import com.vsu.student_council_app.dto.UserDTO;
import com.vsu.student_council_app.request.create.CreateParticipationRequest;
import com.vsu.student_council_app.request.create.CreateParticipationStatusRequest;
import com.vsu.student_council_app.request.create.CreateUserRequest;
import com.vsu.student_council_app.request.update.UpdateParticipationRequest;
import com.vsu.student_council_app.request.update.UpdateUserRequest;
import com.vsu.student_council_app.service.UserService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/by-login")
    public UserDTO getById(@RequestParam String name) {
        return userService.findByLogin(name);
    }

    @PostMapping
    public UserDTO create(@Valid @RequestBody CreateUserRequest createProfileRequest) {
        return userService.createUser(createProfileRequest);
    }
    @PutMapping
    public UserDTO update(@Valid @RequestBody UpdateUserRequest updateProfileRequest) {
        return userService.updateUser(updateProfileRequest);
    }
    @DeleteMapping
    public void delete(@RequestParam long id) {
        userService.deleteUser(id);
    }

}
