package com.vsu.student_council_app.request.create;

import org.hibernate.validator.constraints.Length;

import java.sql.Date;

public class CreateUserRequest {
    @Length(min = 6, message = "login must be not less than 6 symbols")
    private String login;
    private String password;
    private int directionId;
    private int departmentId;
    private String userName;
    private String name;
    private String lastName;
    private String patronymic;
    private short course;
    private Date birthday;
    private String telegramUserName;
    private Date joinDate;
    private boolean active;

    public CreateUserRequest() {
    }

    public CreateUserRequest(String login, String password, int directionId, int departmentId, String userName, String name, String lastName, String patronymic, short course, Date birthday, String telegramUserName, Date joinDate, boolean active) {
        this.login = login;
        this.password = password;
        this.directionId = directionId;
        this.departmentId = departmentId;
        this.userName = userName;
        this.name = name;
        this.lastName = lastName;
        this.patronymic = patronymic;
        this.course = course;
        this.birthday = birthday;
        this.telegramUserName = telegramUserName;
        this.joinDate = joinDate;
        this.active = active;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getDirectionId() {
        return directionId;
    }

    public void setDirectionId(int directionId) {
        this.directionId = directionId;
    }

    public int getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(int departmentId) {
        this.departmentId = departmentId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPatronymic() {
        return patronymic;
    }

    public void setPatronymic(String patronymic) {
        this.patronymic = patronymic;
    }

    public short getCourse() {
        return course;
    }

    public void setCourse(short course) {
        this.course = course;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getTelegramUserName() {
        return telegramUserName;
    }

    public void setTelegramUserName(String telegramUserName) {
        this.telegramUserName = telegramUserName;
    }

    public Date getJoinDate() {
        return joinDate;
    }

    public void setJoinDate(Date joinDate) {
        this.joinDate = joinDate;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Override
    public String toString() {
        return "CreateUserRequest{" +
                "login='" + login + '\'' +
                ", password='" + password + '\'' +
                ", directionId=" + directionId +
                ", departmentId=" + departmentId +
                ", userName='" + userName + '\'' +
                ", name='" + name + '\'' +
                ", lastName='" + lastName + '\'' +
                ", patronymic='" + patronymic + '\'' +
                ", course=" + course +
                ", birthday=" + birthday +
                ", telegramUserName='" + telegramUserName + '\'' +
                ", joinDate=" + joinDate +
                ", active=" + active +
                '}';
    }
}
