package com.vsu.student_council_app.repository;

import com.vsu.student_council_app.Entity.User;
import com.vsu.student_council_app.request.create.CreateUserRequest;
import com.vsu.student_council_app.request.update.UpdateUserRequest;
import com.vsu.student_council_app.utils.PasswordHasher;
import jakarta.validation.Valid;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Repository
public class UserRepository {
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public UserRepository(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    private User mapRowToUser(ResultSet rs) throws SQLException {
        return new User(
                rs.getLong("user_id"),
                rs.getString("login"),
                rs.getString("password"),
                rs.getString("salt"),
                rs.getInt("direction_id"),
                rs.getInt("department_id"),
                rs.getString("user_username"),
                rs.getString("user_name"),
                rs.getString("user_lastname"),
                rs.getString("user_patronymic"),
                rs.getShort("user_course"),
                rs.getDate("user_birthdate"),
                rs.getString("user_telegram_username"),
                rs.getDate("user_join_date"),
                rs.getBoolean("user_is_active")
        );
    }

    public Optional<User> findByLogin(String login) {
        return namedParameterJdbcTemplate.query(
                "SELECT * FROM \"User\" WHERE login = :login",
                Map.of("login", login),
                rs -> rs.next() ? Optional.of(mapRowToUser(rs)) : Optional.empty()
        );
    }

    public Optional<User> findById(long id) {
        return namedParameterJdbcTemplate.query(
                "SELECT * FROM \"User\" WHERE user_id = :id",
                Map.of("id", id),
                rs -> rs.next() ? Optional.of(mapRowToUser(rs)) : Optional.empty()
        );
    }

    public long create(User user) {

        Map<String, Object> params = new HashMap<>();
        userToMap(user, params);

        return namedParameterJdbcTemplate.queryForObject(
                "INSERT INTO \"User\" (" +
                        "direction_id, department_id, " +
                        "user_username, user_name, user_lastname, user_patronymic, " +
                        "user_course, user_birthdate, user_telegram_username, " +
                        "user_join_date, user_is_active, login, password, salt" +
                        ") VALUES (" +
                        ":directionId, :departmentId, " +
                        ":userName, :name, :lastName, :patronymic, " +
                        ":course, :birthday, :telegramUserName, " +
                        ":joinDate, :isActive, :login, :password, :salt" +
                        ") returning user_id",
                params,
                Long.class
        );
    }

    public Optional<User> findByID(long profileId) {
        return namedParameterJdbcTemplate.query(
                "SELECT * FROM \"User\" WHERE user_id = :id",
                Map.of("id", profileId),
                rs -> rs.next() ? Optional.of(mapRowToUser(rs)) : Optional.empty()
        );
    }

    public int update(User user) {
        Map<String, Object> params = new HashMap<>();
        userToMap(user, params);

        // Если нужно обновить пароль - добавляем хеширование
        if (user.getPassword() != null && !user.getPassword().isEmpty()) {
            String salt = PasswordHasher.generateSalt();
            String hashedPassword = PasswordHasher.hashPassword(user.getPassword(), salt);
            params.put("password", hashedPassword);
            params.put("salt", salt);
        }

        String sql = "UPDATE \"User\" SET " +
                "direction_id = :directionId, " +
                "department_id = :departmentId, " +
                "user_username = :userName, " +
                "user_name = :name, " +
                "user_lastname = :lastName, " +
                "user_patronymic = :patronymic, " +
                "user_course = :course, " +
                "user_birthdate = :birthday, " +
                "user_telegram_username = :telegramUserName, " +
                "user_is_active = :isActive" +
                // Добавляем обновление пароля только если он был передан
                (user.getPassword() != null ?
                        ", password = :password, salt = :salt" : "") +
                " WHERE user_id = :userId";

        return namedParameterJdbcTemplate.update(sql, params);
    }

    private static void userToMap(User user, Map<String, Object> params) {
        params.put("login", user.getLogin());
        params.put("password", user.getPassword());
        params.put("salt", user.getSalt());
        params.put("directionId", user.getDirectionId());
        params.put("departmentId", user.getDepartmentId());
        params.put("userName", user.getUserName());
        params.put("name", user.getName());
        params.put("lastName", user.getLastName());
        params.put("patronymic", user.getPatronymic() != null ? user.getPatronymic() : "");
        params.put("course", user.getCourse());
        params.put("birthday", user.getBirthday());
        params.put("telegramUserName", user.getTelegramUserName());
        params.put("joinDate", user.getJoinDate());
        params.put("isActive", user.isActive());
        params.put("userId", user.getId());
    }

    public void delete(long id) {
        namedParameterJdbcTemplate.update(
                "DELETE FROM \"User\" WHERE user_id = :id",
                Map.of("id", id)
        );
    }
}