package com.vsu.student_council_app.controller;

import com.vsu.student_council_app.dto.RankDTO;
import com.vsu.student_council_app.dto.UserInRankDTO;
import com.vsu.student_council_app.request.create.CreateRankRequest;
import com.vsu.student_council_app.request.create.CreateUserInRankRequest;
import com.vsu.student_council_app.request.update.UpdateRankRequest;
import com.vsu.student_council_app.request.update.UpdateUserInRankRequest;
import com.vsu.student_council_app.service.RankService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/rank")
public class RankController {
    private final RankService rankService;

    public RankController(RankService rankService) {
        this.rankService = rankService;
    }

    @GetMapping("/{id}")
    public RankDTO getRank(@PathVariable Long id) {
        return rankService.getById(id);
    }

    @PostMapping("")
    public RankDTO createRank(@RequestBody CreateRankRequest request) {
        return rankService.create(request);
    }

    @PutMapping("")
    public RankDTO updateRank(@RequestBody UpdateRankRequest request) {
        return rankService.update(request);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteRank(@PathVariable Long id) {
        rankService.delete(id);
    }
    @PostMapping("/userInRank")
    public UserInRankDTO createUserInRank(@RequestBody CreateUserInRankRequest request) {
        return  rankService.createUserInRank(request);
    }

    @PutMapping("/userInRank")
    public UserInRankDTO updateUserInRank(@RequestBody UpdateUserInRankRequest request) {
        return  rankService.updateUserInRank(request);
    }

    @GetMapping("/userInRank/{id}")
    public UserInRankDTO getUserInRank(@PathVariable Long id) {
        return  rankService.getUserInRank(id);
    }

    @DeleteMapping("/userInRank/delete/{id}")
    public void deleteUserInRank(@PathVariable Long id) {
        rankService.deleteUserInRank(id);
    }
}
