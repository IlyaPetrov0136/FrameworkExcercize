package com.vsu.student_council_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentCouncilAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(StudentCouncilAppApplication.class, args);
    }

}
