package com.vsu.student_council_app.mappers;

import com.vsu.student_council_app.Entity.Direction;
import com.vsu.student_council_app.dto.DirectionDTO;
import com.vsu.student_council_app.request.create.CreateDirectionRequest;
import com.vsu.student_council_app.request.update.UpdateDirectionRequest;
import org.springframework.stereotype.Component;

@Component
public class DirectionMapper {
    public DirectionDTO directionToDirectionDTO(Direction direction) {
        DirectionDTO directionDTO = new DirectionDTO();
        directionDTO.setId(direction.getId());
        directionDTO.setName(direction.getName());
        return directionDTO;
    }

    public Direction createRequestToDirection(CreateDirectionRequest request) {
        Direction direction = new Direction();
        direction.setName(request.getName());
        return direction;
    }


    public Direction updateRequestToDirection(UpdateDirectionRequest request) {
        Direction direction = new Direction();
        direction.setId(request.getId());
        direction.setName(request.getName());
        return direction;
    }


}
