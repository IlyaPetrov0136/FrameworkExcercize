package com.vsu.student_council_app.controller;

import com.vsu.student_council_app.dto.ParticipationDTO;
import com.vsu.student_council_app.dto.ParticipationStatusDTO;
import com.vsu.student_council_app.request.create.CreateParticipationRequest;
import com.vsu.student_council_app.request.create.CreateParticipationStatusRequest;
import com.vsu.student_council_app.request.update.UpdateParticipationRequest;
import com.vsu.student_council_app.request.update.UpdateParticipationStatusRequest;
import com.vsu.student_council_app.service.ParticipationService;
import com.vsu.student_council_app.service.UserService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/participation")
public class ParticipationController {
    private final ParticipationService participationService;

    public ParticipationController(ParticipationService participationService) {
        this.participationService = participationService;
    }
    @PostMapping("")
    public ParticipationDTO create(@Valid @RequestBody CreateParticipationRequest createRecordRequest) {
        return participationService.createParticipation(createRecordRequest);

    }
    @PutMapping("/edit")
    public ParticipationDTO update(@Valid @RequestBody UpdateParticipationRequest updateRecordRequest) {
        return participationService.updateParticipation(updateRecordRequest);
    }
    @GetMapping("/{id}")
    public ParticipationDTO getRecord(@PathVariable Long id) {
        return participationService.findParticipationById(id);
    }
    @GetMapping("/event/{eventId}")
    public List<ParticipationDTO> getRecordByEvent( @PathVariable int eventId) {
        return participationService.findParticipationsByEvent(eventId);
    }
    @GetMapping("/reason/{reason}")
    public List<ParticipationDTO> getRecordByReason(@PathVariable String reason) {
        return participationService.findParticipationsByReason(reason);
    }
    @DeleteMapping("/delete/{id}")
    public void deleteRecord(@PathVariable Long id) {
        participationService.deleteParticipation(id);
    }
    @PostMapping("/participationStatus")
    public ParticipationStatusDTO createParticipationStatus(@RequestBody CreateParticipationStatusRequest createParticipationStatusRequest) {
        return participationService.createParticipationStatus(createParticipationStatusRequest);
    }
    @GetMapping("/participationStatus/{id}")
    public ParticipationStatusDTO getParticipationStatus(@PathVariable Long id) {
        return participationService.findParticipationStatusById(id);
    }
    @PutMapping("/participationStatus")
    public ParticipationStatusDTO updateParticipationStatus(@RequestBody UpdateParticipationStatusRequest updateParticipationStatusRequest) {
        return  participationService.updateParticipationStatus(updateParticipationStatusRequest);
    }
    @DeleteMapping("/participationStatus/{id}")
    public void deleteParticipationStatus(@PathVariable Long id) {
        participationService.deleteParticipationStatus(id);
    }
}
