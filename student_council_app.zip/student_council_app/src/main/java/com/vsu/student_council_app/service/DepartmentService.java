package com.vsu.student_council_app.service;

import com.vsu.student_council_app.Entity.Department;
import com.vsu.student_council_app.dto.DepartmentDTO;
import com.vsu.student_council_app.exception.ValidationException;
import com.vsu.student_council_app.mappers.DepartmentMapper;
import com.vsu.student_council_app.repository.DepartmentRepository;
import com.vsu.student_council_app.request.create.CreateDepartmentRequest;
import com.vsu.student_council_app.request.update.UpdateDepartmentRequest;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class DepartmentService {
    private final DepartmentRepository departmentRepository;
    private final DepartmentMapper departmentMapper;

    public DepartmentService(DepartmentRepository departmentRepository, DepartmentMapper departmentMapper) {
        this.departmentRepository = departmentRepository;
        this.departmentMapper = departmentMapper;
    }

    public DepartmentDTO create(CreateDepartmentRequest request) {
        if(departmentRepository.findByName(request.getName()).isPresent()) {
            throw new ValidationException("Department with this name already exists");
        }
        Department department = departmentMapper.createDepartmentRequestToDepartment(request);
        Department savedDepartment = departmentRepository.save(department);
        return departmentMapper.departmentToDepartmentDTO(savedDepartment);
    }

    public DepartmentDTO getById(Long id) {
        Department department = departmentRepository.findById(id)
                .orElseThrow(() -> new ValidationException("Department not found"));

        return departmentMapper.departmentToDepartmentDTO(department);
    }

    public DepartmentDTO update(UpdateDepartmentRequest request) {
        if(departmentRepository.findById(request.getId()).isEmpty()) {
            throw new ValidationException("Department not found");
        }

       Department department = departmentMapper.updateDepartmentRequestToDepartment(request);

        Department updatedDepartment = departmentRepository.save(department);
        return departmentMapper.departmentToDepartmentDTO(updatedDepartment);
    }

    public void delete(Long id) {
        if (departmentRepository.findById(id).isEmpty()) {
            throw new ValidationException("Department not found");
        }
        departmentRepository.deleteById(id);
    }
}
