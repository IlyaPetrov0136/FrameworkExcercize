package com.vsu.student_council_app.service;

import com.vsu.student_council_app.Entity.User;
import com.vsu.student_council_app.dto.UserDTO;
import com.vsu.student_council_app.exception.NotFoundException;
import com.vsu.student_council_app.exception.RepositoryException;
import com.vsu.student_council_app.exception.ValidationException;
import com.vsu.student_council_app.mappers.UserMapper;
import com.vsu.student_council_app.repository.*;
import com.vsu.student_council_app.request.create.CreateUserRequest;
import com.vsu.student_council_app.request.update.UpdateUserRequest;
import com.vsu.student_council_app.utils.PasswordHasher;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.stereotype.Service;

import java.util.logging.Logger;

@Service
@Transactional
public class UserService {
    private final static Logger log = Logger.getLogger(UserService.class.getName());
    private final UserRepository userRepository;
    private final UserMapper userMapper;
    private final DirectionRepository directionRepository;
    private final DepartmentRepository departmentRepository;

    public UserService(UserRepository userRepository,
                       UserMapper userMapper, DirectionRepository directionRepository, DepartmentRepository departmentRepository) {
        this.userRepository = userRepository;
        this.userMapper = userMapper;
        this.directionRepository = directionRepository;
        this.departmentRepository = departmentRepository;
    }

    public UserDTO findByLogin(String login) {
        User user = userRepository.findByLogin(login)
                .orElseThrow(() -> new NotFoundException("User not found"));
        return userMapper.toUserDTO(user);
    }

    public UserDTO createUser(@Valid CreateUserRequest createUserRequest) {
        if (userRepository.findByLogin(createUserRequest.getLogin()).isPresent()) {
            throw new ValidationException("User already exists");
        }
        User user = userMapper.createRequestToUser(createUserRequest);
        checkCorrect(user);
        String salt = PasswordHasher.generateSalt();
        user.setSalt(salt);
        user.setPassword(PasswordHasher.hashPassword(user.getPassword(), salt));
        long id = userRepository.create(user);
        if (id != 0) {
            return userMapper.toUserDTO(
                    userRepository.findByID(id).get());
        }
        throw new RepositoryException("Error creating profile");
    }

    public UserDTO updateUser(@Valid UpdateUserRequest updateUserRequest) {
        User user = userMapper.updateUsertoUser(updateUserRequest);
        checkCorrect(user);
        int result = userRepository.update(user);
        log.info("result: "+result);
        if (result == 1) {
            return userMapper.toUserDTO(
                    userRepository.findByID(user.getId()).get());
        }
        throw new RepositoryException("Error creating profile");
    }

    private void checkCorrect(User user) {
        if (directionRepository.findById(user.getDirectionId()).isEmpty()) {
            throw new ValidationException("Direction non exists");
        }
        if (departmentRepository.findById(user.getDepartmentId()).isEmpty()) {
            throw new ValidationException("Department non exists");
        }
    }

    public void deleteUser(long id) {
        if (userRepository.findByID(id).isEmpty()) {
            throw new NotFoundException("User not found");
        }
        try {
            userRepository.delete(id);
        } catch (Exception e) {
            throw new RepositoryException("Error deleting user");
        }
    }
}